import React from "react";
import Iframe from "react-iframe";

function SineWave() {
  return (
    <div>
      <Iframe
        url="https://alab-sine-wave.web.app/"
        width="1200px"
        height="900px"
      />
    </div>
  );
}

export default SineWave;
