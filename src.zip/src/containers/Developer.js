import React from "react";
import "./developers.css";
import developer from "./img/developers.png";
function Developer() {
  return (
    <div>
      <img className="img__developer" src={developer} alt="" />
    </div>
  );
}

export default Developer;
