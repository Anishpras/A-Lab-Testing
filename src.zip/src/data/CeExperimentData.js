const CEExperimentData = [
  {
    name: "Surveying Lab",
    class: "survey",
    link: "ce_survey",
  },
];

export default CEExperimentData;
