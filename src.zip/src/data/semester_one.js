const semester_one = [
  {
    name: "Electrical Engineering",
    teacher: "Prakash Sir",
    class: "electrical",
  },
];

export default semester_one;
