const SubjectData = [
  {
    name: "Electronics Engineering",
    teacher: "Prakash Sir",
    class: "electronics",
  },
  {
    name: "Computer Architecture",
    teacher: "Ravi Sir",
    class: "computer",
  },
];

export default SubjectData;
